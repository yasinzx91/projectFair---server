//logic to resolve the request

exports.register = (req,res)=>{
    console.log('Inside the user controller file');

    res.status(200).json('Registration completed successfully')
}

const express = require('express');

//import controller

const userController = require('../Controllers/userController')

//create an object for router class in the express module 

const router = new express.Router();


//export router

module.exports = router

//path to resolve the request 

    //syntax = router.httpReq('path',()=>{how to solve})

    //register 

    router.post('/user/register',userController.register)